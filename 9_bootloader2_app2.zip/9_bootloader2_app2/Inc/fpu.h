/*
 * fpu.h
 *
 *  Created on: Dec 17, 2024
 *      Author: WILLIAM
 */

#ifndef __FPU_H__
#define __FPU_H__


void fpu_enable(void);

#endif /* FPU_H_ */
