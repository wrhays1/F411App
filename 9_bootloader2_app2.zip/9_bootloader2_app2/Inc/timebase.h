/*
 * timebase.h
 *
 *  Created on: Jan 24, 2025
 *      Author: WILLIAM
 */

#ifndef INC_TIMEBASE_H_
#define INC_TIMEBASE_H_

#include <stdint.h>


#define CTRL_ENABLE    (1U << 0)
#define CTRL_TICKINT   (1U << 1)
#define CTRL_CLOCKSRC  (1U << 2)
#define CTRL_COUNTFLAG (1U << 16)
#define MAX_DELAY       0xFFFFFFFF
#define ONE_SEC_LOAD    16000000

void timebase_init(void);
uint32_t get_tick(void);
#define ONE_mSEC_LOAD   16000
void delay(uint32_t delay);


#endif /* INC_TIMEBASE_H_ */
