/*
 * BASP.c
 *
 *  Created on: Jan 25, 2025
 *      Author: WILLIAM
 */


#include  "bsp.h"
#include "timebase.h"
#include <stdbool.h>
#include <stm32f411xe.h>

#define GPIOAEN   (1U << 0)
#define GPIOCEN   (1U << 2)
#define LED_PIN   (1U << 5)
void led_init(void){

	//enable clock access to GPIOA
	RCC->AHB1ENR |=  GPIOAEN;
	//Set PA5 to output mode
	GPIOA->MODER  |= (1U << 10);
	GPIOA->MODER  &= ~(1U << 11);

}

void led_toggle(uint32_t dly){

	//set PA5 high ot low
	GPIOA->ODR  ^= (LED_PIN);
	delay(dly);

}
void led_on(void){

	//set PA5 high
	GPIOA->ODR  |= (LED_PIN);

}

void led_off(void){

	//set PA5 off
	GPIOA->ODR &= ~(LED_PIN);

}


void button_init(void){
    //BTN is active low
	//enable clock access to PORTC
	RCC->AHB1ENR |= GPIOCEN;
	//Set PC13 as an input pin
	GPIOC->MODER  &= ~(1 << 26);
	GPIOC->MODER  &= ~(1 << 27);
}

bool get_button_state(void){

	//check if btn is pressed
	if(GPIOC->IDR & LED_PIN){

		return false;
	}
	else{
		return true;
	}
}

