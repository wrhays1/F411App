

/**Module
 * FPU
 * UART
 * GPIO
 * TIMEBASE
 *
 *
 *************************************************************
 */


#include <stdint.h>
#include <stdio.h>
#include <fpu.h>
#include <uart.h>
#include "timebase.h"
#include "bsp.h"
#include <stm32f411xe.h>

#define PINS     (1 << 5)


#define VECT_TAB_BASE_ADRESS      FLASH_BASE
#define VECT_TAB_OFFSET           0x8000




#if !defined(__SOFT_FP__) && defined(__ARM_FP)
  #warning "FPU is not initialized, but the project is compiling for an FPU. Please initialize the FPU before use."
#endif

struct btl_common_apis
{
	void(*led_init)(void);
	void(*led_toggle)(uint32_t dly);
	void(*led_on)(void);
	void(*led_off)(void);
	void(*debug_uart_init)(void);
	void(*button_init)(void);
	bool(*get_btn_state)(void);
	void(*fpu_enable)(void);
	void(*timebase_init)(void);

};

int main()
{


	struct btl_common_apis *common_apis = (struct btl_common_apis *)0x0800C000;




	common_apis->fpu_enable();

	/*Initialize debug UART*/
	common_apis->debug_uart_init();

	/*Initialize timebase*/
 	common_apis->timebase_init();

	printf("Application version (2 before loop running....\n\r");

	/*Initialize LED*/
//	common_apis->led_init();

	/*Initialize Push button*/

	//common_apis->button_init();

	while(1)
	{
		printf("Application version (2 mine) is running....\n\r");
	}
}



void SystemInit(void){

	SCB->VTOR = VECT_TAB_BASE_ADRESS + VECT_TAB_OFFSET;
}
