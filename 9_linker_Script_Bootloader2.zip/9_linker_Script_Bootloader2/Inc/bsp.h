/*
 * bsp.h
 *
 *  Created on: Jan 25, 2025
 *      Author: WILLIAM
 */

#ifndef INC_BSP_H_
#define INC_BSP_H_

#include <stdint.h>
#include <stdbool.h>
#include "timebase.h"
#define GPIOAEN   (1U << 0)
#define GPIOCEN   (1U << 2)
#define LED_PIN   (1U << 5)

void led_init(void);
void led_on(void);
void led_off(void);
void led_toggle(uint32_t dly);
void button_init(void);
bool get_button_state(void);

#endif /* INC_BSP_H_ */
