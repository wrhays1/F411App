/*
 * uart.h
 *
 *  Created on: Jan 10, 2025
 *      Author: WILLIAM
 */

#ifndef UART_H_
#define UART_H_





#include <stm32f411xe.h>
#include <stdint.h>

//#define USART_EN
#define USART2_TX   (1UL << 3)
#define AHB1_ENA    (1UL << 0)
#define SR_TE       (1UL << 7)

#define DBG_BAUD_RATE   115200UL

#define SYS_CLK 16000000
#define AHB1_CLK  SYS_CLK

#define APB1_USARTEN  (1UL << 17)
//static uint16_t compute_br (uint32_t periph_clk, uint32_t baudrate);
//static void uart_write(int ch);

void debug_uart_init(void);
//static uint16_t  compute_br(uint32_t periph_clk, uint32_t baudrate);

#endif /* UART_H_ */
