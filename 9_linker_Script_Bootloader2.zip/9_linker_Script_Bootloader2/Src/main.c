

/**Module
 * FPU
 * UART
 * GPIO
 * TIMEBASE
 *
 *
 *************************************************************
 */


#include <stdint.h>
#include <stdio.h>
#include <fpu.h>
#include <uart.h>
#include <timebase.h>
#include "bsp.h"
#include <stm32f411xe.h>
#include <stdbool.h>

#define PINS  (1 << 5)


#define APPLICATION_ADDRESS  0x08008000U
#define MSP_VERIFY_MASK      0x2FFE0000U
#define EMPTY_MEM            0xFFFFFFFFU
typedef void(*func_ptr)(void);
void led_toggle(uint32_t);
bool get_button_state(void);

void jmp_to_default_app(void)
{
	uint32_t app_start_address;
	func_ptr jump_to_app;

	printf("Bootloader Started....\n\r");
//	delay(300);

	/*Version 1*/
//#ifdef MEM_CHECKK_V1
//	if(((*(uint32_t *)APPLICATION_ADDRESS) & MSP_VERIFY_MASK ) ==  0x20020000)
//#endif

//#ifdef MEM_CHECKK_V2

	/*Version 2*/
	if((*(uint32_t *)APPLICATION_ADDRESS) != EMPTY_MEM)


	{
		printf("Starting application.....\n\r");
		app_start_address =  *(uint32_t *)(APPLICATION_ADDRESS + 4);

		jump_to_app = (func_ptr) app_start_address;

		/*Initialialize main stack pointer*/
		__set_MSP(*(uint32_t *)APPLICATION_ADDRESS);

		/*jump*/
		jump_to_app();

	}
	else

		printf("No application found at location....\n\r");



}


struct btl_common_apis
{
	void(*led_init)(void);
	void(*led_toggle)(uint32_t dly);
	void(*led_on)(void);
	void(*led_off)(void);
	void(*debug_uart_init)(void);
	void(*button_init)(void);
	bool(*get_btn_state)(void);
	void(*fpu_enable)(void);
	void(*timebase_init)(void);

};


struct btl_common_apis common_apis  __attribute__((section(".COMMON_APIS")))= {
		led_init,
		led_toggle,
		led_on,
		led_off,
		debug_uart_init,
		button_init,
		get_button_state,
		fpu_enable,
		timebase_init

};


int main(void)
{


	 fpu_enable();
     debug_uart_init();
     timebase_init();
    // led_init();
   //  led_init();


    delay(300);
    printf("Hello for STM32 linker boot application\n\r");



    jmp_to_default_app();


}

