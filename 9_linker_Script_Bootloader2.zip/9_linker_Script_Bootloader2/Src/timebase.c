/*
 * timebase.c
 *
 *  Created on: Jan 24, 2025
 *      Author: WILLIAM
 */

#include "timebase.h"
#include <stm32f411xe.h>
#include <stdint.h>

#define ONE_mSEC_LOAD   16000
uint32_t get_tick(void);

#define TICK_FREQ    1
 uint32_t g_curr_tick;
 uint32_t g_curr_tick_p;


/*delay in seconds*/

void delay(uint32_t delay){

  	uint32_t tickstart = get_tick();
	uint32_t wait = delay;
	if(wait < MAX_DELAY){
		wait  += (uint32_t) TICK_FREQ;
	}
	while((get_tick() - tickstart ) < wait){}
}


uint32_t get_tick(void){

	__disable_irq();
	g_curr_tick_p =  g_curr_tick;
	__enable_irq();

	return g_curr_tick_p;
}


void tick_increment(void){

	g_curr_tick += (uint32_t)(TICK_FREQ);
}

void timebase_init(void){

	//Disable global Interrupts
	__disable_irq();

	//load timer with number of clock clcles per second
	SysTick->LOAD = ONE_mSEC_LOAD - 1;

	//Clear systick current value register
	SysTick->VAL = 0;

	//select internal clock source
	SysTick->CTRL = CTRL_CLOCKSRC;

	//enable interrupt
	SysTick->CTRL |= CTRL_TICKINT;

	//Enable systick
	SysTick->CTRL |= CTRL_ENABLE;
	//Enable global interrupts
	__enable_irq();
}

void SysTick_Handler(void){

	tick_increment();

}
