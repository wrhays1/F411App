/*
 * uart.c
 *
 *  Created on: Jan 10, 2025
 *      Author: WILLIAM
 */




#include "uart.h"

#include <stdint.h>
#include <stm32f411xe.h>
#include <fpu.h>

static void uart_write(int ch);
static void uart_write(int ch);
static void uart_set_baudrate(uint32_t periph_clk,uint32_t baudrate);



int __io_putchar(int ch){

	uart_write(ch);
	return ch;
}
void debug_uart_init(void){

	//to_do:

	/*enable clock access to GPIOA*/
	RCC->AHB1ENR |= AHB1_ENA;

	/*Set the mode of PA2 to alt function mode*/
	GPIOA->MODER &= ~(1U << 4);
	GPIOA->MODER |=  (1U << 5);

	/*Set ALT function type to AF7(UART2)*/
	GPIOA->AFR[0] |= (1U << 8);
	GPIOA->AFR[0] |= (1U << 9);
	GPIOA->AFR[0] |= (1U << 10);
	GPIOA->AFR[0] &= ~(1U << 11);



	/*Enable clock for  UART2 */

	RCC->APB1ENR |= APB1_USARTEN;
	/*Configure UART baud rate */
	uart_set_baudrate(AHB1_CLK, DBG_BAUD_RATE);

	/* Configure Transfer Direction TX only*/
	 //set bit 3 to 1 the rest to 0
	USART2->CR1 = USART2_TX;
	/*Enable UART Module*/
	USART2->CR1 |=  (1UL << 13) ;  //set bit 13 only

}


static void uart_write(int ch){

	while(!(USART2->SR & SR_TE)){}

	USART2->DR = (ch & 0xFF);


}

static uint16_t compute_uart_bd(uint32_t periph_clk,uint32_t baudrate)
{
	return((periph_clk + (baudrate/2U))/baudrate);
}

static void uart_set_baudrate(uint32_t periph_clk,uint32_t baudrate)
{
	USART2->BRR = compute_uart_bd(periph_clk,baudrate);
}

